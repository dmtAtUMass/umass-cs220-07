import fetch from "../include/fetch.js";
export function fetchUniversities(query) {
    // TODO
    const searchURL = new URL("https://220.maxkuechen.com/universities/search");
    searchURL.searchParams.set("name", query);
    return fetch(searchURL)
        .then(response => response.json())
        .then(json => json.map((university) => university.name));
}
//# sourceMappingURL=fetchUniversities.js.map